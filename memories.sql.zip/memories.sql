-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 03/04/2024 às 18:05
-- Versão do servidor: 11.2.2-MariaDB
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: memories
--
CREATE DATABASE IF NOT EXISTS memories DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE memories;

-- --------------------------------------------------------

--
-- Estrutura para tabela cadavel
--

DROP TABLE IF EXISTS cadavel;
CREATE TABLE IF NOT EXISTS cadavel (
  id int(11) NOT NULL AUTO_INCREMENT,
  nome varchar(30) DEFAULT NULL,
  bairro varchar(30) DEFAULT NULL,
  tell varchar(15) DEFAULT NULL,
  cemiterio int(11) NOT NULL,
  avenida varchar(10) DEFAULT NULL,
  sexo varchar(10) DEFAULT NULL,
  data_nasc date DEFAULT NULL,
  bi varchar(30) DEFAULT NULL,
  dh varchar(25) DEFAULT NULL,
  ft char(1) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY cemiterio (cemiterio)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela campa
--

DROP TABLE IF EXISTS campa;
CREATE TABLE IF NOT EXISTS campa (
  id_campa int(11) NOT NULL AUTO_INCREMENT,
  num_campa int(11) NOT NULL,
  PRIMARY KEY (id_campa)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela campa
--

INSERT INTO campa (id_campa, num_campa) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

-- --------------------------------------------------------

--
-- Estrutura para tabela campa_cem
--

DROP TABLE IF EXISTS campa_cem;
CREATE TABLE IF NOT EXISTS campa_cem (
  id_ca_cem int(11) NOT NULL AUTO_INCREMENT,
  cem int(11) NOT NULL,
  campa int(11) DEFAULT NULL,
  PRIMARY KEY (id_ca_cem),
  KEY cem (cem),
  KEY campa (campa)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela campa_cem
--

INSERT INTO campa_cem (id_ca_cem, cem, campa) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 4, 1),
(4, 4, 2),
(5, 7, 1),
(6, 7, 2),
(7, 2, 1),
(8, 2, 2),
(9, 3, 1),
(10, 3, 2),
(11, 3, 3),
(12, 3, 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela cem
--

DROP TABLE IF EXISTS cem;
CREATE TABLE IF NOT EXISTS cem (
  id_cem int(11) NOT NULL AUTO_INCREMENT,
  nome_cem varchar(50) NOT NULL,
  localizacao varchar(50) NOT NULL,
  PRIMARY KEY (id_cem)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela cem
--

INSERT INTO cem (id_cem, nome_cem, localizacao) VALUES
(1, 'Catorze', 'Cazenga'),
(2, 'Viana', 'Viana'),
(3, 'Santana', 'Kilamba Kiaxi');

-- --------------------------------------------------------

--
-- Estrutura para tabela quarteirao
--

DROP TABLE IF EXISTS quarteirao;
CREATE TABLE IF NOT EXISTS quarteirao (
  id_qua int(11) NOT NULL AUTO_INCREMENT,
  num_qua int(11) NOT NULL,
  PRIMARY KEY (id_qua)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela quarteirao
--

INSERT INTO quarteirao (id_qua, num_qua) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela quarteirao_cem
--

DROP TABLE IF EXISTS quarteirao_cem;
CREATE TABLE IF NOT EXISTS quarteirao_cem (
  id_qt_cem int(11) NOT NULL AUTO_INCREMENT,
  cemiterio int(11) NOT NULL,
  quarteirao int(11) NOT NULL,
  PRIMARY KEY (id_qt_cem),
  KEY cemiterio (cemiterio),
  KEY quarteirao (quarteirao)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela quarteirao_cem
--

INSERT INTO quarteirao_cem (id_qt_cem, cemiterio, quarteirao) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1),
(5, 2, 2),
(6, 2, 3),
(7, 3, 1),
(8, 3, 2),
(9, 3, 3),
(10, 1, 4);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
